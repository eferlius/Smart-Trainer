using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

// This is the Right Hand class, work exactly in the same way of the Left Hand class
// The only difference is that the Right Hand has more methods because has to perform more types of motions 
public class RightHand : MonoBehaviour
{
    Animator animator;
    
    private float closing;
    private float opening;
    private float pronation;
    private float supination;

    private string closeParam = "Closing";
    private string closeParam25 = "Closing25";
    private string closeParam50 = "Closing50";
    private string closeParam75 = "Closing75";
    private string closeParam100 = "Closing100";

    private string openParam = "Opening";
    private string openParam25 = "Opening25";
    private string openParam50 = "Opening50";
    private string openParam75 = "Opening75";
    private string openParam100 = "Opening100";

    private string pronParam = "Pronation";
    private string pronParam25 = "Pronation25";
    private string pronParam50 = "Pronation50";
    private string pronParam75 = "Pronation75";
    private string pronParam100 = "Pronation100";

    private string supParam = "Supination";
    private string supParam25 = "Supination25";
    private string supParam50 = "Supination50";
    private string supParam75 = "Supination75";
    private string supParam100 = "Supination100";

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        
    }

    internal void SetClosing(float n1)
    {
        closing = n1;
    }

    internal void SetOpening(float n2)
    {
        opening = n2;
    }

    internal void SetPronation(float n3)
    {
        pronation = n3;
    }

    internal void SetSupination(float n4)
    {
        supination = n4;
    }

    internal void CloseHand()
    {
        SetClosing(0.5f);
        animator.SetFloat(closeParam, closing);
    }

    internal void Close25Hand()
    {
        SetClosing(0.5f);
        animator.SetFloat(closeParam25, closing);
    }

    internal void Close50Hand()
    {
        SetClosing(0.5f);
        animator.SetFloat(closeParam50, closing);
    }

    internal void Close75Hand()
    {
        SetClosing(0.5f);
        animator.SetFloat(closeParam75, closing);
    }

    internal void Close100Hand()
    {
        SetClosing(0.5f);
        animator.SetFloat(closeParam100, closing);
    }

    internal void CloseToRest()
    {
        SetClosing(0.0f);
        animator.SetFloat(closeParam, closing);
    }

    internal void Close25ToRest()
    {
        SetClosing(0.0f);
        animator.SetFloat(closeParam25, closing);
    }

    internal void Close50To25()
    {
        SetClosing(0.0f);
        animator.SetFloat(closeParam50, closing);
    }

    internal void Close75To50()
    {
        SetClosing(0.0f);
        animator.SetFloat(closeParam75, closing);
    }

    internal void Close100To75()
    {
        SetClosing(0.0f);
        animator.SetFloat(closeParam100, closing);
    }

    internal void Close100ToRest()
    {
        SetClosing(0.5f);
        animator.SetFloat(closeParam, closing);
    }

    internal void ResetClosing()
    {
        SetClosing(0.0f);
        animator.SetFloat(closeParam25, closing);
        animator.SetFloat(closeParam50, closing);
        animator.SetFloat(closeParam75, closing);
        animator.SetFloat(closeParam100, closing);
        animator.SetFloat(closeParam, closing);
    }

    internal void OpenHand()
    {
        SetOpening(0.5f);
        animator.SetFloat(openParam, opening);
    }

    internal void Open25Hand()
    {
        SetOpening(0.5f);
        animator.SetFloat(openParam25, opening);
    }

    internal void Open50Hand()
    {
        SetOpening(0.5f);
        animator.SetFloat(openParam50, opening);
    }

    internal void Open75Hand()
    {
        SetOpening(0.5f);
        animator.SetFloat(openParam75, opening);
    }

    internal void Open100Hand()
    {
        SetOpening(0.5f);
        animator.SetFloat(openParam100, opening);
    }

    internal void OpenToRest()
    {
        SetOpening(0.0f);
        animator.SetFloat(openParam, opening);
    }

    internal void Open25ToRest()
    {
        SetOpening(0.0f);
        animator.SetFloat(openParam25, opening);
    }

    internal void Open50To25()
    {
        SetOpening(0.0f);
        animator.SetFloat(openParam50, opening);
    }

    internal void Open75To50()
    {
        SetOpening(0.0f);
        animator.SetFloat(openParam75, opening);
    }

    internal void Open100To75()
    {
        SetOpening(0.0f);
        animator.SetFloat(openParam100, opening);
    }

    internal void Open100ToRest()
    {
        SetOpening(0.0f);
        animator.SetFloat(openParam, opening);
    }

    internal void ResetOpening()
    {
        SetOpening(0.0f);
        animator.SetFloat(openParam25, opening);
        animator.SetFloat(openParam50, opening);
        animator.SetFloat(openParam75, opening);
        animator.SetFloat(openParam100, opening);
        animator.SetFloat(openParam, opening);
    }

    internal void PronationHand()
    {
        SetPronation(0.5f);
        animator.SetFloat(pronParam, pronation);
    }
    internal void Pron25Hand()
    {
        SetPronation(0.5f);
        animator.SetFloat(pronParam25, pronation);
    }

    internal void Pron50Hand()
    {
        SetPronation(0.5f);
        animator.SetFloat(pronParam50, pronation);
    }

    internal void Pron75Hand()
    {
        SetPronation(0.5f);
        animator.SetFloat(pronParam75, pronation);
    }

    internal void Pron100Hand()
    {
        SetPronation(0.5f);
        animator.SetFloat(pronParam100, pronation);
    }

    internal void PronationToRest()
    {
        SetPronation(0.0f);
        animator.SetFloat(pronParam, pronation);
    }

    internal void Pron25ToRest()
    {
        SetPronation(0.0f);
        animator.SetFloat(pronParam25, pronation);
    }

    internal void Pron50To25()
    {
        SetPronation(0.0f);
        animator.SetFloat(pronParam50, pronation);
    }

    internal void Pron75To50()
    {
        SetPronation(0.0f);
        animator.SetFloat(pronParam75, pronation);
    }

    internal void Pron100To75()
    {
        SetPronation(0.0f);
        animator.SetFloat(pronParam100, pronation);
    }

    internal void Pron100ToRest()
    {
        SetOpening(0.0f);
        animator.SetFloat(pronParam, opening);
    }

    internal void ResetPronation()
    {
        SetPronation(0.0f);
        animator.SetFloat(pronParam25, pronation);
        animator.SetFloat(pronParam50, pronation);
        animator.SetFloat(pronParam75, pronation);
        animator.SetFloat(pronParam100, pronation);
        animator.SetFloat(pronParam, pronation);
    }

    internal void SupinationHand()
    {
        SetSupination(0.5f);
        animator.SetFloat(supParam, supination);
    }
    internal void Sup25Hand()
    {
        SetSupination(0.5f);
        animator.SetFloat(supParam25, supination);
    }

    internal void Sup50Hand()
    {
        SetSupination(0.5f);
        animator.SetFloat(supParam50, supination);
    }

    internal void Sup75Hand()
    {
        SetSupination(0.5f);
        animator.SetFloat(supParam75, supination);
    }

    internal void Sup100Hand()
    {
        SetSupination(0.5f);
        animator.SetFloat(supParam100, supination);
    }
    internal void SupinationToRest()
    {
        SetSupination(0.0f);
        animator.SetFloat(supParam, supination);
    }
    internal void Sup25ToRest()
    {
        SetSupination(0.0f);
        animator.SetFloat(supParam25, supination);
    }

    internal void Sup50To25()
    {
        SetSupination(0.0f);
        animator.SetFloat(supParam50, supination);
    }

    internal void Sup75To50()
    {
        SetSupination(0.0f);
        animator.SetFloat(supParam75, supination);
    }

    internal void Sup100To75()
    {
        SetSupination(0.0f);
        animator.SetFloat(supParam100, supination);
    }

    internal void Sup100ToRest()
    {
        SetSupination(0.0f);
        animator.SetFloat(supParam, supination);
    }
    
    // This method resets all the variables and animations of the right hand 
    internal void ResetSupination()
    {
        SetSupination(0.0f);
        animator.SetFloat(supParam25, supination);
        animator.SetFloat(supParam50, supination);
        animator.SetFloat(supParam75, supination);
        animator.SetFloat(supParam100, supination);
        animator.SetFloat(supParam, supination);
    }
}