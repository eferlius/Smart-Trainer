using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

// This is the last level class, the Extreme class
public class Extreme : MonoBehaviour
{
    // The working principle of this level is equal to the Intermediate one
    // The only difference is in the error handling. When an error occurs the game is stopped and the ExitState is activated 
    public LeftHand leftHand;
    public RightHand rightHand;

    private int closeLabel = 1;
    private int openLabel = 2;
    private int pronLabel = 3;
    private int supLabel = 4;

    private int label;

    private bool closeRestState;
    private bool close25State;
    private bool close50State;
    private bool close75State;
    private bool closeState;

    private bool openRestState;
    private bool open25State;
    private bool open50State;
    private bool open75State;
    private bool openState;

    private bool pronRestState;
    private bool pron25State;
    private bool pron50State;
    private bool pron75State;
    private bool pronState;

    private bool supRestState;
    private bool sup25State;
    private bool sup50State;
    private bool sup75State;
    private bool supState;

    private bool exitState;

    public TextMeshProUGUI timer;
    private float elapsedTime = 0;

    public TextMeshProUGUI timerClose;
    public GameObject closingText;

    public TextMeshProUGUI timerOpen;
    public GameObject openingText;

    public TextMeshProUGUI timerPron;
    public GameObject pronationText;

    public TextMeshProUGUI timerSup;
    public GameObject supinationText;

    public GameObject countdownText;
    private float countdown;

    public GameObject oneText;
    public GameObject twoText;
    public GameObject threeText;

    private float timerClosing = 0f;
    private float timerOpening = 0f;
    private float timerPronation = 0f;
    private float timerSupination = 0f;

    public GameObject restartButton;
    public GameObject changeButton;
    public GameObject quitButton;
    public GameObject background;
    public GameObject wellDone;
    public GameObject payAttention;
    public GameObject gameOver;

    TcpListener listener;
    String msg;

    // Start is called before the first frame update
    void Start()
    {
        listener = new TcpListener(55001);
        listener.Start();

        closeRestState = true;
        close25State = false;
        close50State = false;
        close75State = false;
        closeState = false;

        openRestState = false;
        open25State = false;
        open50State = false;
        open75State = false;
        openState = false;

        pronRestState = false;
        pron25State = false;
        pron50State = false;
        pron75State = false;
        pronState = false;

        supRestState = false;
        sup25State = false;
        sup50State = false;
        sup75State = false;
        supState = false;

        exitState = false;

        closingText.SetActive(true);
        openingText.SetActive(true);
        pronationText.SetActive(true);
        supinationText.SetActive(true);

        restartButton.SetActive(false);
        changeButton.SetActive(false);
        quitButton.SetActive(false);
        background.SetActive(false);
        wellDone.SetActive(false);
        payAttention.SetActive(false);
        gameOver.SetActive(false);

        oneText.SetActive(false);
        twoText.SetActive(false);
        threeText.SetActive(true);

        countdownText.SetActive(true);
        countdown = 3f;
    }

    // Update is called once per frame
    void Update()
    {
        if (countdown > 0)
        {
            countdown -= Time.deltaTime;
            if (countdown <= 1 & countdown > 0)
            {
                oneText.SetActive(true);
                twoText.SetActive(false);
            }
            if (countdown <= 2 & countdown > 1)
            {
                twoText.SetActive(true);
                threeText.SetActive(false);
            }
            if (countdown <= 3 & countdown > 2)
            {
                threeText.SetActive(true);
            }
        }
        else
        {
            countdownText.SetActive(false);
            // Listener is waiting for the data from Matlab
            if (!listener.Pending())
            {
                if (closeRestState || close25State || close50State || close75State || closeState)
                {
                    leftHand.SupinationToRest();
                    leftHand.CloseHand();
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);
                }

                if (openRestState || open25State || open50State || open75State || openState)
                {
                    leftHand.CloseToRest();
                    leftHand.OpenHand();
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);
                }

                if (pronRestState || pron25State || pron50State || pron75State || pronState)
                {
                    leftHand.OpenToRest();
                    leftHand.PronationHand();
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);
                }

                if (supRestState || sup25State || sup50State || sup75State || supState || exitState)
                {
                    leftHand.PronationToRest();
                    leftHand.SupinationHand();
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);
                }

            }
            else // data are coming from Matlab
            {
                TcpClient client = listener.AcceptTcpClient();
                NetworkStream ns = client.GetStream();
                StreamReader reader = new StreamReader(ns);

                msg = reader.ReadToEnd();
                label = int.Parse(msg);

                wellDone.SetActive(false);
                payAttention.SetActive(false);

                if (closeRestState)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == closeLabel)
                    {
                        rightHand.Close25Hand();
                        wellDone.SetActive(true);
                        closeRestState = false;
                        close25State = true;
                        label = 0;
                    }
                    if (label == openLabel)
                    {
                        gameOver.SetActive(true);
                        closeRestState = false;
                        exitState = true;
                    }
                }

                if (close25State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == closeLabel)
                    {
                        rightHand.Close50Hand();
                        wellDone.SetActive(true);
                        close25State = false;
                        close50State = true;
                        label = 0;
                    }
                    if (label == openLabel)
                    {
                        gameOver.SetActive(true);
                        close25State = false;
                        exitState = true;
                    }
                }

                if (close50State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == closeLabel)
                    {
                        rightHand.Close75Hand();
                        wellDone.SetActive(true);
                        close50State = false;
                        close75State = true;
                        label = 0;
                    }
                    if (label == openLabel)
                    {
                        gameOver.SetActive(true);
                        close50State = false;
                        exitState = true;
                    }
                }

                if (close75State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == closeLabel)
                    {
                        rightHand.Close100Hand();
                        wellDone.SetActive(true);
                        close75State = false;
                        closeState = true;
                        label = 0;
                    }
                    if (label == openLabel)
                    {
                        gameOver.SetActive(true);
                        close75State = false;
                        exitState = true;
                    }
                }

                if (closeState)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);
                    timerClosing = elapsedTime;
                    DisplayTime(timerClose, timerClosing);
                    rightHand.Close100ToRest();
                    rightHand.ResetClosing();
                    wellDone.SetActive(true);
                    closeState = false;
                    openRestState = true;
                    label = 0;
                    elapsedTime = 0;
                }

                if (openRestState)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == openLabel)
                    {
                        rightHand.Open25Hand();
                        wellDone.SetActive(true);
                        openRestState = false;
                        open25State = true;
                        label = 0;
                    }
                    if (label == closeLabel)
                    {
                        gameOver.SetActive(true);
                        openRestState = false;
                        exitState = true;
                    }
                }

                if (open25State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == openLabel)
                    {
                        rightHand.Open50Hand();
                        wellDone.SetActive(true);
                        open25State = false;
                        open50State = true;
                        label = 0;
                    }
                    if (label == closeLabel)
                    {
                        gameOver.SetActive(true);
                        open25State = false;
                        exitState = true;
                    }
                }

                if (open50State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == openLabel)
                    {
                        rightHand.Open75Hand();
                        wellDone.SetActive(true);
                        open50State = false;
                        open75State = true;
                        label = 0;
                    }
                    if (label == closeLabel)
                    {
                        gameOver.SetActive(true);
                        open50State = false;
                        exitState = true;
                    }
                }

                if (open75State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == openLabel)
                    {
                        rightHand.Open100Hand();
                        wellDone.SetActive(true);
                        open75State = false;
                        openState = true;
                        label = 0;
                    }
                    if (label == closeLabel)
                    {
                        gameOver.SetActive(true);
                        open75State = false;
                        exitState = true;
                    }
                }

                if (openState)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);
                    timerOpening = elapsedTime;
                    DisplayTime(timerOpen, timerOpening);
                    rightHand.Open100ToRest();
                    rightHand.ResetOpening();
                    wellDone.SetActive(true);
                    openState = false;
                    pronRestState = true;
                    label = 0;
                    elapsedTime = 0;
                }

                if (pronRestState)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == pronLabel)
                    {
                        rightHand.Pron25Hand();
                        wellDone.SetActive(true);
                        pronRestState = false;
                        pron25State = true;
                        label = 0;
                    }
                    if (label == supLabel)
                    {
                        gameOver.SetActive(true);
                        pronRestState = false;
                        exitState = true;
                    }
                }

                if (pron25State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == pronLabel)
                    {
                        rightHand.Pron50Hand();
                        wellDone.SetActive(true);
                        pron25State = false;
                        pron50State = true;
                        label = 0;
                    }
                    if (label == supLabel)
                    {
                        gameOver.SetActive(true);
                        pron25State = false;
                        exitState = true;
                    }
                }

                if (pron50State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == pronLabel)
                    {
                        rightHand.Pron75Hand();
                        wellDone.SetActive(true);
                        pron50State = false;
                        pron75State = true;
                        label = 0;
                    }
                    if (label == supLabel)
                    {
                        gameOver.SetActive(true);
                        pron50State = false;
                        exitState = true;
                    }
                }

                if (pron75State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == pronLabel)
                    {
                        rightHand.Pron100Hand();
                        wellDone.SetActive(true);
                        pron75State = false;
                        pronState = true;
                        label = 0;
                    }
                    if (label == supLabel)
                    {
                        gameOver.SetActive(true);
                        pron75State = false;
                        exitState = true;
                    }
                }

                if (pronState)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);
                    timerPronation = elapsedTime;
                    DisplayTime(timerPron, timerPronation);
                    rightHand.Pron100ToRest();
                    rightHand.ResetPronation();
                    wellDone.SetActive(true);
                    pronState = false;
                    supRestState = true;
                    label = 0;
                    elapsedTime = 0;
                }

                if (supRestState)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == supLabel)
                    {
                        rightHand.Sup25Hand();
                        wellDone.SetActive(true);
                        supRestState = false;
                        sup25State = true;
                        label = 0;
                    }
                    if (label == pronLabel)
                    {
                        gameOver.SetActive(true);
                        supRestState = false;
                        exitState = true;
                    }
                }

                if (sup25State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == supLabel)
                    {
                        rightHand.Sup50Hand();
                        wellDone.SetActive(true);
                        sup25State = false;
                        sup50State = true;
                        label = 0;
                    }
                    if (label == pronLabel)
                    {
                        gameOver.SetActive(true);
                        sup25State = false;
                        exitState = true;
                    }
                }

                if (sup50State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == supLabel)
                    {
                        rightHand.Sup75Hand();
                        wellDone.SetActive(true);
                        sup50State = false;
                        sup75State = true;
                        label = 0;
                    }
                    if (label == pronLabel)
                    {
                        gameOver.SetActive(true);
                        sup50State = false;
                        exitState = true;
                    }
                }

                if (sup75State)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);

                    if (label == supLabel)
                    {
                        rightHand.Sup100Hand();
                        wellDone.SetActive(true);
                        sup75State = false;
                        supState = true;
                        label = 0;
                    }
                    if (label == pronLabel)
                    {
                        gameOver.SetActive(true);
                        sup75State = false;
                        exitState = true;
                    }
                }

                if (supState)
                {
                    elapsedTime += Time.deltaTime;
                    DisplayTime(timer, elapsedTime);
                    timerSupination = elapsedTime;
                    DisplayTime(timerSup, timerSupination);
                    rightHand.Sup100ToRest();
                    rightHand.ResetSupination();
                    wellDone.SetActive(true);
                    supState = false;
                    exitState = true;
                    label = 0;
                    elapsedTime = 0;
                }

                if (exitState)
                {
                    leftHand.SupinationToRest();
                    rightHand.ResetClosing();
                    rightHand.ResetOpening();
                    rightHand.ResetPronation();
                    rightHand.ResetSupination();
                    restartButton.SetActive(true);
                    changeButton.SetActive(true);
                    quitButton.SetActive(true);
                    background.SetActive(true);
                }
            }
        }
    }

    // These methods are present and explained in the Beginner Class
    void DisplayTime(TextMeshProUGUI timer, float timeToDisplay)
    {
        timeToDisplay += 1;

        float minutes = Mathf.FloorToInt(timeToDisplay / 60);
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);
        float milliseconds = (timeToDisplay % 1) * 1000;

        timer.text = string.Format("{0:00}:{1:00}:{2:00}", minutes, seconds, milliseconds);
    }

    public void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void ChangeDifficulty()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 4);
    }

    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Game closed");
    }
}