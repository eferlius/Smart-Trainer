using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.SceneManagement;

// This is the Main Menu class: 
public class MainMenu : MonoBehaviour
{
    // Create an object listener of type TcpListener that is used to establish the connection with Matlab
    TcpListener listener;

    // This is the function that is connected with the button Quit in the Menu
    public void ExitButton()
    {
        // This line of code terminate the execution of the program
        Application.Quit();
        // After the closing procedure write on the Log: "Game Closed"
        Debug.Log("Game closed");
    }

    // This is the function that is connected with the button Start in the Menu
    public void StartGame()
    {
        // Create the listener
        listener = new TcpListener(55001);
        // Start the listner
        listener.Start();
        // This line of code change the scene after the user push the button start
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    // It is important that the method are public because otherwise it is not possible to attach them the button 
}