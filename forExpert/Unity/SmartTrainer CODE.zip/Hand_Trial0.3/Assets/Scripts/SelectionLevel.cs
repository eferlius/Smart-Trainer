using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// This is the Level Selection class
public class SelectionLevel : MonoBehaviour
{
    // There is a definition of four method, all public, that change the scene to the next correct scene
    public void Playgound()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void Beginner()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
    }

    public void Intermediate()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 3);
    }

    public void Extreme()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 4);
    }

    // It is important to know the index of the scene. All the scenes have to be inserted in the BUILD SETTINGS in the correct order
}