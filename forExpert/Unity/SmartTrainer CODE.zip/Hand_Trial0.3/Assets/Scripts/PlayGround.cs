using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

// This is the Playground class
public class PlayGround : MonoBehaviour
{
    // In this level is present only the Right Hand, so we call a public object of type RightHand
    public RightHand rightHand;

    // These lines define some constants that are the labels associated at every movement
    private int closeLabel = 1;
    private int openLabel = 2;
    private int pronLabel = 3;
    private int supLabel = 4;
    
    // This is the label in which the label message coming from Matlab is stored
    private int label;

    // These lines define four boolean parameter that are activated when the movements are finished
    private bool closingFinished;
    private bool openingFinished;
    private bool pronationFinished;
    private bool supinationFinished;

    // wait is a boolean parameter used to wait n-seconds before starting the game
    private bool wait;

    // Three public buttons of type GameObject
    public GameObject changeButton;
    public GameObject quitButton;
    public GameObject background;

    // Four public text of type GameObject
    public GameObject countdownText;
    public GameObject oneText;
    public GameObject twoText;
    public GameObject threeText;

    // Float variable to make a countdown used before the start of the game
    private float countdown;

    // Create a listener of type TcpListener because the connection with Matlab is of type TCPIP
    TcpListener listener;

    // In this parameter of type String is stored the message coming from Matlab
    String msg;

    // Start is called before the first frame update
    void Start()
    {
        listener = new TcpListener(55001);
        listener.Start();

        // These lines set all the gameObject of the scene to active or disable, some object have to enabled and some disabled
        changeButton.SetActive(true);
        quitButton.SetActive(true);
        background.SetActive(true);

        countdownText.SetActive(true);

        oneText.SetActive(false);
        twoText.SetActive(false);
        threeText.SetActive(true);

        // The countdown variable is set to 3 (float) in order to wait three seconds
        countdown = 3f;

        // wait is set to true
        wait = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (countdown > 0)
        {
            // This line decrement the value of countdown of an amount of Time.deltaTime (this method knows how many time has passed form each frames)
            countdown -= Time.deltaTime;
            if (wait)
            {
                // These lines implements the countdown of three seconds
                if (countdown <= 1 & countdown > 0)
                {
                    oneText.SetActive(true);
                    twoText.SetActive(false);
                }
                if (countdown <= 2 & countdown > 1)
                {
                    twoText.SetActive(true);
                    threeText.SetActive(false);
                }
                if (countdown <= 3 & countdown > 2)
                {
                    threeText.SetActive(true);
                }
            }
        }
        else // once the timer is elapsed
        {
            wait = false;
            // Set the countdown variable to half second used to wait the end of the movements execution
            countdown = 0.5f;
            oneText.SetActive(false);
            countdownText.SetActive(false);

            // Listener is waiting for the data from Matlab
            if (!listener.Pending())
            {
                // After the closing animation is finished, this method reset the position of the right hand
                if (closingFinished)
                {
                    rightHand.CloseToRest();
                    closingFinished = false;
                }

                // These lines work in the same way as the one above
                if (openingFinished)
                {
                    rightHand.OpenToRest();
                    openingFinished = false;
                }

                if (pronationFinished)
                {
                    rightHand.PronationToRest();
                    pronationFinished = false;
                }

                if (supinationFinished)
                {
                    rightHand.SupinationToRest();
                    supinationFinished = false;
                }
            }
            else // data are coming from Matlab
            {
                // Once the data are coming from Matlab a client is created and all the setup to allow it to work is created
                TcpClient client = listener.AcceptTcpClient();
                NetworkStream ns = client.GetStream();
                StreamReader reader = new StreamReader(ns);

                // The messages coming from Matlab is read with the metohd ReadToEnd() and stored in the varianle msg
                msg = reader.ReadToEnd();
                // In label we stored the int convertion of the string msg
                label = int.Parse(msg);

                // These lines check if the label from Matlab is equal to one of the label of the motion. If it is true perform the associated movement.
                if (label == closeLabel)
                {
                    rightHand.CloseHand();
                    closingFinished = true;
                }
                else if (label == openLabel)
                {
                    rightHand.OpenHand();
                    openingFinished = true;
                }
                else if (label == pronLabel)
                {
                    rightHand.PronationHand();
                    pronationFinished = true;
                }
                else if (label == supLabel)
                {
                    rightHand.SupinationHand();
                    supinationFinished = true;
                }
            }
        }
    }

    // This public method is used by the ChangeLevel button to return to the level selection scene
    public void ChangeDifficulty()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
    }

    // This public method is used by the QuitGame button to stop the execution of the game
    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Game closed");
    }
}