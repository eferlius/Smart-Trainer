using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

// This is the Left Hand class
public class LeftHand : MonoBehaviour
{
    // This line create an object of type Animator called animator, this is used to control the animation of the Left Hand
    Animator animator;

    // These are the definition of four parameters that have to be set to change the conditions of the animator. One for each animation
    private float closing;
    private float opening;
    private float pronation;
    private float supination;

    // These are four constant that are used to not write every time the string
    private string closeParam = "Closing";
    private string openParam = "Opening";
    private string pronParam = "Pronation";
    private string supParam = "Supination";

    void Start()
    {
        // Activate the animator
        animator = GetComponent<Animator>();
    }

    void Update()
    {
    
    }

    // These lines are all the methods needed to actuate in the correct way all the motion. It is important to define them as internal otherwise it is not possible to call them in other scripts
    // The set methods change the value of the parameter: closing, opening, pronation and supination
    internal void SetClosing(float n1)
    {
        closing = n1;
    }

    internal void SetOpening(float n2)
    {
        opening = n2;
    }

    internal void SetPronation(float n3)
    {
        pronation = n3;
    }

    internal void SetSupination(float n4)
    {
        supination = n4;
    }

    // This method set the parameter closing at 0.5 (float) in order to open the hand
    internal void CloseHand()
    {
        SetClosing(0.5f);
        // Set the value of closeParam in the animator equal to the value of closing, this allow to the animation to start
        animator.SetFloat(closeParam, closing);
    }

    // All the methods below work in the same way as the CloseHand method
    internal void CloseToRest()
    {
        SetClosing(0.0f);
        animator.SetFloat(closeParam, closing);
    }

    internal void OpenHand()
    {
        SetOpening(0.5f);
        animator.SetFloat(openParam, opening);
    }

    internal void OpenToRest()
    {
        SetOpening(0.0f);
        animator.SetFloat(openParam, opening);
    }

    internal void PronationHand()
    {
        SetPronation(0.5f);
        animator.SetFloat(pronParam, pronation);
    }

    internal void PronationToRest()
    {
        SetPronation(0.0f);
        animator.SetFloat(pronParam, pronation);
    }

    internal void SupinationHand()
    {
        SetSupination(0.5f);
        animator.SetFloat(supParam, supination);
    }

    internal void SupinationToRest()
    {
        SetSupination(0.0f);
        animator.SetFloat(supParam, supination);
    }
}