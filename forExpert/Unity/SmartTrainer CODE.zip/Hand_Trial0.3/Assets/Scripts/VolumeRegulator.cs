using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// This is the Volume Regulator class
public class VolumeRegulator : MonoBehaviour
{
    // Are been defined two objects, one is the AudioSource (before you have to create a component of type AudioSource) and the other is the Slider (create an object UI Slider)
    public AudioSource audioSource;
    public Slider audioSlider;

    // Definition of a float parameter that is the gain of the volume
    private float musicVolume = 1f;

    // Start is called before the first frame update
    void Start()
    {
        // Play the audio source
        audioSource.Play();
        // Saves in the player preferences the volume (this is made to save the value of the volume in all the scenes)
        musicVolume = PlayerPrefs.GetFloat("volume");
        // Set the volume of the source to the one of musicVolume
        audioSource.volume = musicVolume;
        // Change the value of musicVolume according to the slider position
        audioSlider.value = musicVolume;
    }

    // Update is called once per frame
    void Update()
    {
        // At every frame update the volume of the audioSource with the correct parameter
        audioSource.volume = musicVolume;
        // Save the current value in the player preferences
        PlayerPrefs.SetFloat("volume", musicVolume);
    }

    // public method that have to be attached to the slider
    public void UpdateVolume(float volume)
    {
        musicVolume = volume;
    }
}