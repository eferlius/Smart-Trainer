using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

// This is the Beginner class
public class Beginner : MonoBehaviour
{
    // In this level there are two hands, Left and Right
    public LeftHand leftHand;
    public RightHand rightHand;

    // These lines are the same that are present in the Playground class
    private int closeLabel = 1;
    private int openLabel = 2;
    private int pronLabel = 3;
    private int supLabel = 4;

    private int label;

    private bool closingTask;
    private bool openingTask;
    private bool pronationTask;
    private bool supinationTask;

    // Define all the necessary parameter to create a timer
    public TextMeshProUGUI timer;
    public int time;
    private float executionTime;
    private float timeRemaining;

    public GameObject countdownText;
    private float countdown;

    public GameObject oneText;
    public GameObject twoText;
    public GameObject threeText;

    // Define all the parameter to count the repetition
    public TextMeshProUGUI reps;
    public int numberOfRepetition;
    private int executedRepes = 1;

    // Define the parameter to count and print the errors in the screen
    public TextMeshProUGUI textErrors;
    private int errors = 0;

    public GameObject restartButton;
    public GameObject changeButton;
    public GameObject quitButton;
    public GameObject background;
    public GameObject wellDone;
    public GameObject payAttention;

    TcpListener listener;
    String msg;

    // Start is called before the first frame update
    void Start()
    {
        listener = new TcpListener(55001);
        listener.Start();

        closingTask = true;
        openingTask = false;
        pronationTask = false;
        supinationTask = false;

        executionTime = (float) time - 1f;
        timeRemaining = executionTime;

        restartButton.SetActive(false);
        changeButton.SetActive(false);
        quitButton.SetActive(false);
        background.SetActive(false);
        wellDone.SetActive(false);
        payAttention.SetActive(false);

        oneText.SetActive(false);
        twoText.SetActive(false);
        threeText.SetActive(true);

        countdownText.SetActive(true);
        countdown = 3f;
    }

    // Update is called once per frame
    void Update()
    {
        // At the beginning call this two methods to set the counter of the errors and of the repetition at zero
        SetCountErrors();
        SetCountReps();
        // If the repetition are terminated this condition is true
        if (executedRepes == (numberOfRepetition+1))
        {
            // So the left hand is resetted and the button to endle the execution of the game are set active
            leftHand.SupinationToRest();
            restartButton.SetActive(true);
            changeButton.SetActive(true);
            quitButton.SetActive(true);
            background.SetActive(true);
        }

        // Countdown of three seconds before the start of the game, used to have time to press play on Matlab
        if (countdown > 0)
        {
            countdown -= Time.deltaTime;
            if (countdown <= 1 & countdown > 0)
            {
                oneText.SetActive(true);
                twoText.SetActive(false);
            }
            if (countdown <= 2 & countdown > 1)
            {
                twoText.SetActive(true);
                threeText.SetActive(false);
            }
            if (countdown <= 3 & countdown > 2)
            {
                threeText.SetActive(true);
            }
        }
        else // Once the countdown is elapsed
        {
            oneText.SetActive(false);
            countdownText.SetActive(false);

            // Listener is waiting for the data from Matlab
            if (!listener.Pending())
            {
                // If the left hand has to execute the closing operation
                if (closingTask)
                {
                    // the left hand is closed
                    leftHand.CloseHand();
                    // After half the seconds are elapsed the Closing operetion is performed again
                    if (timeRemaining <= 0.501 * executionTime & timeRemaining >= 0.499 * executionTime)
                    {
                        leftHand.CloseToRest();
                    }
                    // The user has a limited amount of time (timeRemeaning) to perform the closing, this time can be set from the Unity interface
                    if (timeRemaining > 0)
                    {
                        timeRemaining -= Time.deltaTime;
                        // Update the timer at every frame 
                        DisplayTime(timeRemaining);
                    }
                    else // If the time available to carried out the closing is elapsed
                    {
                        // Print on the Log that the closing operation is finished
                        Debug.Log("CLOSE time has run out!");
                        // Reset the timer
                        timeRemaining = executionTime;
                        // Reset the position of the Right and Left Hands
                        leftHand.CloseToRest();
                        rightHand.CloseToRest();
                        // Change the state of the boolean variable to execute the next task
                        closingTask = false;
                        openingTask = true;
                    }
                }

                // All the code below works exactly as the closingTask part just explained
                if (openingTask)
                {
                    leftHand.OpenHand();
                    if (timeRemaining <= 0.501 * executionTime & timeRemaining >= 0.499 * executionTime)
                    {
                        leftHand.OpenToRest();
                    }
                    if (timeRemaining > 0)
                    {
                        timeRemaining -= Time.deltaTime;
                        DisplayTime(timeRemaining);
                    }
                    else
                    {
                        Debug.Log("OPEN time has run out!");
                        timeRemaining = executionTime;
                        leftHand.OpenToRest();
                        rightHand.OpenToRest();
                        openingTask = false;
                        pronationTask = true;
                    }
                }

                if (pronationTask)
                {
                    leftHand.PronationHand();
                    if (timeRemaining <= 0.6 * executionTime & timeRemaining >= 0.5 * executionTime)
                    {
                        leftHand.PronationToRest();
                    }
                    if (timeRemaining > 0)
                    {
                        timeRemaining -= Time.deltaTime;
                        DisplayTime(timeRemaining);
                    }
                    else
                    {
                        Debug.Log("PRONATION time has run out!");
                        timeRemaining = executionTime;
                        leftHand.PronationToRest();
                        rightHand.PronationToRest();
                        pronationTask = false;
                        supinationTask = true;
                    }
                }

                if (supinationTask)
                {
                    leftHand.SupinationHand();
                    if (timeRemaining <= 0.53 * executionTime & timeRemaining >= 0.51 * executionTime)
                    {
                        leftHand.SupinationToRest();
                    }
                    if (timeRemaining > 0)
                    {
                        timeRemaining -= Time.deltaTime;
                        DisplayTime(timeRemaining);
                    }
                    else
                    {
                        Debug.Log("SUPINATION time has run out!");
                        timeRemaining = executionTime;
                        leftHand.SupinationToRest();
                        rightHand.SupinationToRest();
                        supinationTask = false;
                        closingTask = true;
                        executedRepes += 1;
                    }
                }
            }
            else // data are coming from Matlab
            {
                TcpClient client = listener.AcceptTcpClient();
                NetworkStream ns = client.GetStream();
                StreamReader reader = new StreamReader(ns);

                msg = reader.ReadToEnd();
                label = int.Parse(msg);

                wellDone.SetActive(false);
                payAttention.SetActive(false);

                // If the task that has to execute is the closing operation
                if (closingTask)
                {
                    // If the label is equal to the closing one 
                    if (label == closeLabel)
                    {
                        // The right hand closing
                        rightHand.CloseHand();
                        // A well done message is set to active in order to give feedback to the user
                        wellDone.SetActive(true);
                    }
                    // If the label is opposite to the one needed to activate the motion
                    if (label == openLabel)
                    {
                        // The right hand position is reset
                        rightHand.CloseToRest();
                        // A pay attention message is set active in order to give feedback to the user
                        payAttention.SetActive(true);
                        // The amount of error is increased
                        errors += 1;
                        // And the counter message is updated
                        SetCountErrors();
                    }
                    if (timeRemaining > 0)
                    {
                        timeRemaining -= Time.deltaTime;
                        DisplayTime(timeRemaining);
                    }
                    else // After the time to perform the closing is elapsed
                    {
                        Debug.Log("CLOSE time has run out!");
                        timeRemaining = executionTime;
                        leftHand.CloseToRest();
                        rightHand.CloseToRest();
                        closingTask = false;
                        openingTask = true;
                    }
                }

                // All the lines below work as the closingTask
                if (openingTask)
                {
                    if (label == openLabel)
                    {
                        rightHand.OpenHand();
                        wellDone.SetActive(true);
                    }
                    if (label == closeLabel)
                    {
                        rightHand.OpenToRest();
                        payAttention.SetActive(true);
                        errors += 1;
                        SetCountErrors();
                    }
                    if (timeRemaining > 0)
                    {
                        timeRemaining -= Time.deltaTime;
                        DisplayTime(timeRemaining);
                    }
                    else
                    {
                        Debug.Log("OPEN time has run out!");
                        timeRemaining = executionTime;
                        leftHand.OpenToRest();
                        rightHand.OpenToRest();
                        openingTask = false;
                        pronationTask = true;
                    }
                }

                if (pronationTask)
                {
                    if (label == pronLabel)
                    {
                        rightHand.PronationHand();
                        wellDone.SetActive(true);
                    }
                    if (label == supLabel)
                    {
                        rightHand.PronationToRest();
                        payAttention.SetActive(true);
                        errors += 1;
                        SetCountErrors();
                    }
                    if (timeRemaining > 0)
                    {
                        timeRemaining -= Time.deltaTime;
                        DisplayTime(timeRemaining);
                    }
                    else
                    {
                        Debug.Log("PRONATION time has run out!");
                        timeRemaining = executionTime;
                        leftHand.PronationToRest();
                        rightHand.PronationToRest();
                        pronationTask = false;
                        supinationTask = true;
                    }
                }

                if (supinationTask)
                {
                    if (label == supLabel)
                    {
                        rightHand.SupinationHand();
                        wellDone.SetActive(true);
                    }
                    if (label == pronLabel)
                    {
                        rightHand.SupinationToRest();
                        payAttention.SetActive(true);
                        errors += 1;
                        SetCountErrors();
                    }
                    if (timeRemaining > 0)
                    {
                        timeRemaining -= Time.deltaTime;
                        DisplayTime(timeRemaining);
                    }
                    else
                    {
                        Debug.Log("SUPINATION time has run out!");
                        timeRemaining = executionTime;
                        leftHand.SupinationToRest();
                        rightHand.SupinationToRest();
                        supinationTask = false;
                        closingTask = true;
                        executedRepes += 1;
                    }
                }
            }
        }  
    }

    // This method is used to update and print the timer
    void DisplayTime(float timeToDisplay)
    {
        timeToDisplay += 1;

        float seconds = Mathf.FloorToInt(timeToDisplay % 60);
        float milliseconds = (timeToDisplay % 1) * 1000;

        timer.text = string.Format("{0:00}:{1:00}", seconds, milliseconds);
    }

    // This public method is used by the RestartLevel button to restart the execution of the game
    public void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    // This public method is used by the ChangeLevel button to return to the level selection scene
    public void ChangeDifficulty()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 2);
    }

    // This public method is used by the QuitGame button to stop the execution of the game
    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Game closed");
    }

    // This method is used to update the errorText, this method also change the color of the text based on the amount of the errors committed
    void SetCountErrors()
    {
        if (errors >= 0 & errors < 3)
        {
            textErrors.color = Color.green;
            textErrors.text = "Current Errors: " + errors.ToString();
        }
        else if (errors >= 3 & errors < 5)
        {
            textErrors.color = Color.yellow;
            textErrors.text = "Current Errors: " + errors.ToString();
        }
        else if (errors >= 5)
        {
            textErrors.color = Color.red;
            textErrors.text = "Current Errors: " + errors.ToString();
        }
    }

    // This method is used to update the repetition message
    void SetCountReps()
    {
        reps.text = "Repetition Number: " + executedRepes.ToString();
    }
}